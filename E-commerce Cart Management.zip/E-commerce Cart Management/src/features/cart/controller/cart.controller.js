// Please don't change the pre-written code
// Import the necessary modules here
import { addToCart, removeFromCart } from "../model/cart.model.js";

export const addToCartController = (req, res) => {
  // Write your code here
  const { productId, quantity } = req.query;
  const userId = req.userId;
  const item = addToCart(userId, productId, quantity);
  return res.status(200).send({ success: true, item });
};

export const removeFromCartController = (req, res) => {
  // Write your code here
  const id = req.params.itemId;
  const userId = req.userId;
  const isdeleted = removeFromCart(userId, id);
  if (isdeleted) {
    return res.status(200).send({ success: true, deletedCartItem: isdeleted });
  }
  return res.status(400).send({ success: false, msg: "operation not allowed" });
};
